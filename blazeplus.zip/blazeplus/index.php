<?php
require_once 'config.php';

if (($_SESSION['user_type'] ?? '') !== 'user' || empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$myId = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param('i', $myId);
$stmt->execute();
$me = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$me) { session_destroy(); header('Location: login.php'); exit; }

// ---- Level-based visibility ----
// employee: sees other employees only (hide_contact respected between employees)
// manager: sees employees (ignores hide_contact) + other managers
// senior: sees managers + employees + other seniors (hide_contact respected among seniors)
$myRole = $me['role'];
if ($myRole === 'employee') {
    $visibleRoles = ['employee'];
} elseif ($myRole === 'manager') {
    $visibleRoles = ['employee', 'manager'];
} else { // senior
    $visibleRoles = ['employee', 'manager', 'senior'];
}

$placeholders = implode(',', array_fill(0, count($visibleRoles), '?'));
$types = str_repeat('s', count($visibleRoles));
$stmt = $conn->prepare("SELECT * FROM users WHERE role IN ($placeholders) ORDER BY name ASC");
$stmt->bind_param($types, ...$visibleRoles);
$stmt->execute();
$result = $stmt->get_result();
$employees = [];
while ($r = $result->fetch_assoc()) { $employees[] = $r; }
$stmt->close();

function contactVisible($viewer, $target) {
    if ($target['id'] == $viewer['id']) return true;
    if (!$target['hide_contact']) return true;
    // hide_contact only hides from peers of the SAME role level
    // employee hiding -> hidden from other employees
    // senior hiding -> hidden from other seniors
    // managers currently always visible (per spec: managers see all emp incl. hidden ones;
    // no rule defined for managers hiding from employees, so managers are never masked)
    if ($target['role'] === 'employee' && $viewer['role'] === 'employee') return false;
    if ($target['role'] === 'senior' && $viewer['role'] === 'senior') return false;
    return true;
}

$roomDept = $me['department'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Directory · BlazePlus</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="app-shell">
  <div class="sidebar">
    <div>
      <div class="brand">Blaze<span>Plus</span></div>
      <div class="nav-section-label">Workspace</div>
      <a href="#directory" class="nav-item active"><span class="label">Directory</span></a>
      <a href="#transfers" class="nav-item"><span class="label">Transfers</span></a>
      <div class="nav-section-label">Rooms · <?= htmlspecialchars($roomDept) ?></div>
      <a href="#" class="nav-item soon"><span class="label">#<?= strtolower(htmlspecialchars($roomDept)) ?></span></a>
      <a href="#" class="nav-item soon"><span class="label">#general</span></a>
      <a href="#" class="nav-item soon"><span class="label">#<?= strtolower(htmlspecialchars($roomDept)) ?>-announcements</span></a>
      <a href="#" class="nav-item soon"><span class="label">#all-announcements</span></a>
    </div>
    <div class="sidebar-user">
      <?= htmlspecialchars($me['name']) ?><br>
      <span class="mono"><?= htmlspecialchars($me['emp_no']) ?></span> · <?= ucfirst($me['role']) ?><br>
      <a href="logout.php" style="color:#BFE3D6;">Log out</a>
    </div>
  </div>

  <div class="main">
    <div class="main-header">
      <div>
        <h1 id="directory">Employee Directory</h1>
        <div class="sub">You're viewing as <?= ucfirst($myRole) ?> — <?= count($employees) ?> people visible to you.</div>
      </div>
    </div>

    <input type="text" class="search-bar" id="searchInput" placeholder="Search by name or department…">

    <div class="directory-grid" id="grid">
      <?php foreach ($employees as $emp): ?>
        <?php $canSee = contactVisible($me, $emp); ?>
        <div class="id-card" data-name="<?= strtolower(htmlspecialchars($emp['name'])) ?>" data-dept="<?= strtolower(htmlspecialchars($emp['department'])) ?>">
          <div class="card-role"><?= ucfirst($emp['role']) ?></div>
          <h3><?= htmlspecialchars($emp['name']) ?><?= $emp['id'] == $me['id'] ? ' (You)' : '' ?></h3>
          <div class="dept"><?= htmlspecialchars($emp['department']) ?></div>
          <div class="row"><span class="k">ID</span> <?= htmlspecialchars($emp['emp_no']) ?></div>
          <?php if ($canSee): ?>
            <div class="row"><span class="k">Phone</span> <?= htmlspecialchars($emp['phone']) ?></div>
          <?php else: ?>
            <div class="row locked">Contact hidden by this user</div>
          <?php endif; ?>
          <a href="#" class="view-link" onclick="alert('Full profile view — coming soon'); return false;">View details →</a>
        </div>
      <?php endforeach; ?>
    </div>

    <div style="margin-top:40px;">
      <h1 id="transfers" style="font-size:18px;">Transfers</h1>
      <div class="sub" style="margin-bottom:14px;">Track department/role transfer requests.</div>
      <div class="room-card" style="max-width:340px;">
        <div class="tag">MODULE</div>
        <h3>Coming soon</h3>
        <div class="status">Transfer tracking isn't built yet.</div>
      </div>
    </div>

    <div style="margin-top:40px;">
      <h1 style="font-size:18px;">Chat Rooms</h1>
      <div class="sub" style="margin-bottom:14px;">Rooms are assigned automatically based on your department and can't be changed.</div>
      <div class="rooms-grid">
        <div class="room-card">
          <div class="tag">DEPARTMENT</div>
          <h3>#<?= strtolower(htmlspecialchars($roomDept)) ?></h3>
          <div class="status">Coming soon</div>
        </div>
        <div class="room-card">
          <div class="tag">ALL DEPARTMENTS</div>
          <h3>#general</h3>
          <div class="status">Coming soon</div>
        </div>
        <div class="room-card">
          <div class="tag">DEPARTMENT</div>
          <h3>#<?= strtolower(htmlspecialchars($roomDept)) ?>-announcements</h3>
          <div class="status">Coming soon</div>
        </div>
        <div class="room-card">
          <div class="tag">ALL DEPARTMENTS</div>
          <h3>#all-announcements</h3>
          <div class="status">Coming soon</div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
document.getElementById('searchInput').addEventListener('input', function() {
  const q = this.value.toLowerCase();
  document.querySelectorAll('#grid .id-card').forEach(card => {
    const match = card.dataset.name.includes(q) || card.dataset.dept.includes(q);
    card.style.display = match ? '' : 'none';
  });
});
</script>
</body>
</html>
